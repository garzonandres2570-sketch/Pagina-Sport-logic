package com.proyecto.sportlogic2.controller;

import com.proyecto.sportlogic2.model.Entrenamiento;
import com.proyecto.sportlogic2.repository.EntrenamientoRepository;
import com.proyecto.sportlogic2.service.PdfService;
import com.itextpdf.text.DocumentException; 
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/entrenamientos")
public class EntrenamientoController {

    private final EntrenamientoRepository repo;
    private final PdfService pdfService;

    public EntrenamientoController(EntrenamientoRepository repo, PdfService pdfService) {
        this.repo = repo;
        this.pdfService = pdfService;
    }

    
    @GetMapping("/jugador")
    public String listarEntrenamientosJugador(Model model) {
        model.addAttribute("entrenamientos", repo.findAll());
        return "jugador/entrenamientos";
    }

    
    @GetMapping({"/entrenador", "/entrenadoresa"})
    public String listarEntrenamientosEntrenador(Model model) {
        model.addAttribute("entrenamientos", repo.findAll());
        return "entrenador/entrenamientos";
    }

    @GetMapping("/nuevo")
    public String nuevoForm(Model model) {
        model.addAttribute("entrenamiento", new Entrenamiento());
        return "entrenador/entrenamiento-form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Entrenamiento e) {
        repo.save(e);
        return "redirect:/entrenamientos/entrenador";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("entrenamiento", repo.findById(id).orElseThrow());
        return "entrenador/entrenamiento-form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        repo.deleteById(id);
        return "redirect:/entrenamientos/entrenador";
    }

    
    @GetMapping("/exportar/pdf")
    public void exportarPDF(HttpServletResponse response) {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=entrenamientos.pdf");

        List<Entrenamiento> lista = repo.findAll();
        try {
            pdfService.generarEntrenamientosPdf(lista, response);
        } catch (DocumentException | IOException ex) {
            throw new RuntimeException("Error generando PDF de entrenamientos", ex);
        }
    }
}
