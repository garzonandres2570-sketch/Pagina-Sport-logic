package com.proyecto.sportlogic2.controller;

import com.proyecto.sportlogic2.model.Jugador;
import com.proyecto.sportlogic2.model.Usuario;
import com.proyecto.sportlogic2.repository.JugadorRepository;
import com.proyecto.sportlogic2.repository.UsuarioRepository;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final JugadorRepository jugadorRepo;
    private final UsuarioRepository usuarioRepo;
    private final PasswordEncoder passwordEncoder;

    public AdminController(JugadorRepository jugadorRepo,
                           UsuarioRepository usuarioRepo,
                           PasswordEncoder passwordEncoder) {
        this.jugadorRepo = jugadorRepo;
        this.usuarioRepo = usuarioRepo;
        this.passwordEncoder = passwordEncoder;
    }

    
    @GetMapping("/home")
    public String home() {
        return "admin/home";
    }

    
    @GetMapping("/jugadores")
    public String listarJugadores(Model model) {
        model.addAttribute("jugadores", jugadorRepo.findAll());
        return "admin/jugadores";
    }

    
    @GetMapping("/jugadores/nuevo")
    public String nuevoJugador(Model model) {
        model.addAttribute("jugador", new Jugador());
        return "admin/jugador-form";
    }

    
    @PostMapping("/jugadores/guardar")
    public String guardarJugador(@ModelAttribute Jugador jugador) {
        String password = "12345";

        Usuario usuario = usuarioRepo.findByEmail(jugador.getEmail())
                .orElse(new Usuario());

        usuario.setNombre(jugador.getNombre());
        usuario.setEmail(jugador.getEmail());
        usuario.setRol("DEPORTISTA");
        usuario.setPassword(passwordEncoder.encode(password));

        usuarioRepo.save(usuario);
        jugadorRepo.save(jugador);

        return "redirect:/admin/jugadores?success";
    }

    
    @GetMapping("/jugadores/editar/{id}")
    public String editarJugador(@PathVariable Long id, Model model) {
        Jugador jugador = jugadorRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Jugador no encontrado"));
        model.addAttribute("jugador", jugador);
        return "admin/jugador-form";
    }

    
    @GetMapping("/jugadores/eliminar/{id}")
    public String eliminarJugador(@PathVariable Long id) {
        jugadorRepo.deleteById(id);
        return "redirect:/admin/jugadores?deleted";
    }

    
    @GetMapping("/jugadores/report")
    @ResponseBody
    public void exportarPDF(HttpServletResponse response) throws IOException {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=jugadores.pdf");

        Document document = new Document();
        try {
            PdfWriter.getInstance(document, response.getOutputStream());
            document.open();

            document.add(new Paragraph("Reporte de Jugadores"));
            document.add(new Paragraph(" "));

            
            PdfPTable table = new PdfPTable(6);
            table.setWidthPercentage(100);

            
            table.addCell(new PdfPCell(new Paragraph("ID")));
            table.addCell(new PdfPCell(new Paragraph("Nombre")));
            table.addCell(new PdfPCell(new Paragraph("Email")));
            table.addCell(new PdfPCell(new Paragraph("Posición")));
            table.addCell(new PdfPCell(new Paragraph("Nacionalidad")));
            table.addCell(new PdfPCell(new Paragraph("Edad")));

            
            List<Jugador> jugadores = jugadorRepo.findAll();
            for (Jugador j : jugadores) {
                table.addCell(String.valueOf(j.getId()));
                table.addCell(j.getNombre() != null ? j.getNombre() : "");
                table.addCell(j.getEmail() != null ? j.getEmail() : "");
                table.addCell(j.getPosicion() != null ? j.getPosicion() : "");
                table.addCell(j.getNacionalidad() != null ? j.getNacionalidad() : "");
                table.addCell(j.getEdad() != null ? String.valueOf(j.getEdad()) : "");
            }

            document.add(table);

        } catch (DocumentException e) {
            throw new IOException(e);
        } finally {
            document.close();
        }
    }
}
