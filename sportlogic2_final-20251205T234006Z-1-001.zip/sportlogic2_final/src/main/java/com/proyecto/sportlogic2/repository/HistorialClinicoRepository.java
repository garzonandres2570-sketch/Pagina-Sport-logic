package com.proyecto.sportlogic2.repository;

import com.proyecto.sportlogic2.model.HistorialClinico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface HistorialClinicoRepository extends JpaRepository<HistorialClinico, Long> {

    @Query("SELECT h FROM HistorialClinico h " +
            "WHERE (:nombre IS NULL OR :nombre = '' OR LOWER(h.jugador.nombre) LIKE LOWER(CONCAT('%', :nombre, '%'))) " +
            "AND (:diagnostico IS NULL OR :diagnostico = '' OR LOWER(h.diagnostico) LIKE LOWER(CONCAT('%', :diagnostico, '%')))")
    List<HistorialClinico> findByFiltros(
            @Param("nombre") String nombre,
            @Param("diagnostico") String diagnostico
    );
}
