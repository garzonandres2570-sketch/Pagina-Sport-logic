package com.proyecto.sportlogic2.service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.springframework.stereotype.Service;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@Service
public class GlobalPdfService {

    public <T> void exportarLista(HttpServletResponse response,
                                  String tituloReporte,
                                  List<T> datos,
                                  String[] headers,
                                  PdfDataMapper<T> mapper) throws IOException {

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=" + tituloReporte + ".pdf");

        try {
            Document document = new Document(PageSize.A4.rotate()); // horizontal si la tabla es grande
            PdfWriter.getInstance(document, response.getOutputStream());
            document.open();

            
            Font fontTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK);
            Paragraph titulo = new Paragraph("Reporte - " + tituloReporte, fontTitulo);
            titulo.setAlignment(Element.ALIGN_CENTER);
            document.add(titulo);
            document.add(new Paragraph(" "));

            
            PdfPTable table = new PdfPTable(headers.length);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10);

            
            for (String h : headers) {
                PdfPCell cell = new PdfPCell(new Phrase(h, FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
                table.addCell(cell);
            }

           
            for (T dato : datos) {
                List<String> valores = mapper.map(dato);
                for (String v : valores) {
                    table.addCell(v != null ? v : "");
                }
            }

            document.add(table);
            document.close();

        } catch (DocumentException e) {
            throw new IOException("Error generando PDF: " + e.getMessage());
        }
    }

    
    @FunctionalInterface
    public interface PdfDataMapper<T> {
        List<String> map(T dato);
    }
}
