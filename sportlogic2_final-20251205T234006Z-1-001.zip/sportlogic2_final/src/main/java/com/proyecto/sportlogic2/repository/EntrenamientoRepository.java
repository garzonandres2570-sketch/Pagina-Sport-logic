package com.proyecto.sportlogic2.repository;

import com.proyecto.sportlogic2.model.Entrenamiento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EntrenamientoRepository extends JpaRepository<Entrenamiento, Long> {

    @Query("""
        SELECT e FROM Entrenamiento e
        WHERE (:titulo IS NULL OR LOWER(e.titulo) LIKE LOWER(CONCAT('%', :titulo, '%')))
          AND (:lugar IS NULL OR LOWER(e.lugar) LIKE LOWER(CONCAT('%', :lugar, '%')))
    """)
    List<Entrenamiento> findByFiltros(@Param("titulo") String titulo,
                                      @Param("lugar") String lugar);
}
