package com.proyecto.sportlogic2.controller;

import com.proyecto.sportlogic2.model.Usuario;
import com.proyecto.sportlogic2.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@Controller
public class AuthController {

    private final UsuarioRepository repo;
    private final PasswordEncoder pe;

    public AuthController(UsuarioRepository repo, PasswordEncoder pe) {
        this.repo = repo;
        this.pe = pe;
    }

    
    @GetMapping({"/", "/home"})
    public String home() {
        return "index";
    }

    
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    
    @GetMapping("/registro")
    public String registro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "registro";
    }

    
    @PostMapping("/registro")
    public String registrar(@Valid @ModelAttribute Usuario usuario,
                            BindingResult bindingResult,
                            Model model) {
        if (bindingResult.hasErrors()) {
            return "registro";
        }

        if (repo.findByEmail(usuario.getEmail()).isPresent()) {
            model.addAttribute("error", "El correo ya está en uso");
            return "registro";
        }

        usuario.setPassword(pe.encode(usuario.getPassword()));

        if (usuario.getRol() == null || usuario.getRol().isBlank()) {
            usuario.setRol("ROLE_DEPORTISTA"); // ⚡ Ahora con prefijo ROLE_
        }

        repo.save(usuario);
        return "redirect:/login?registrado";
    }
}
