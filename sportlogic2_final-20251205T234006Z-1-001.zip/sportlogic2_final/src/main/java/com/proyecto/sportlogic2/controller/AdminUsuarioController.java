package com.proyecto.sportlogic2.controller;

import com.proyecto.sportlogic2.model.Usuario;
import com.proyecto.sportlogic2.repository.UsuarioRepository;
import com.proyecto.sportlogic2.service.GlobalPdfService;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/admin/usuarios")
public class AdminUsuarioController {

    private final UsuarioRepository repo;
    private final GlobalPdfService pdfService;

    public AdminUsuarioController(UsuarioRepository repo, GlobalPdfService pdfService) {
        this.repo = repo;
        this.pdfService = pdfService;
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String nombre,
                         @RequestParam(required = false) String email,
                         @RequestParam(required = false) String rol,
                         Model model) {

        List<Usuario> usuarios = repo.findByFiltros(nombre, email, rol);
        model.addAttribute("usuarios", usuarios);
        model.addAttribute("f_nombre", nombre);
        model.addAttribute("f_email", email);
        model.addAttribute("f_rol", rol);
        return "admin/usuarios";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "admin/usuario-form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Usuario usuario) {
        repo.save(usuario);
        return "redirect:/admin/usuarios";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Usuario u = repo.findById(id).orElse(null);
        model.addAttribute("usuario", u);
        return "admin/usuario-form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        repo.deleteById(id);
        return "redirect:/admin/usuarios";
    }

   
    @GetMapping("/pdf")
    public void exportarPdf(HttpServletResponse response) throws IOException {
        List<Usuario> usuarios = repo.findAll();

        String[] headers = {"ID", "Nombre", "Email", "Rol"};

        pdfService.exportarLista(response, "Usuarios", usuarios, headers, u ->
                List.of(
                        u.getId() != null ? u.getId().toString() : "",
                        u.getNombre(),
                        u.getEmail(),
                        u.getRol()
                )
        );
    }
}
