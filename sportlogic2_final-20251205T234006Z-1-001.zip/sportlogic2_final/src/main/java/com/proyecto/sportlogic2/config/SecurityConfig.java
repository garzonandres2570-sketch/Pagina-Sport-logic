package com.proyecto.sportlogic2.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                        "/", "/index", "/registro", "/login",
                        "/css/**", "/js/**", "/images/**", "/h2-console/**"
                ).permitAll()
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .requestMatchers("/deportista/**").hasRole("DEPORTISTA")
                .requestMatchers("/medico/**").hasRole("MEDICO")
                .requestMatchers("/entrenador/**").hasRole("ENTRENADOR")
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .successHandler(customAuthenticationSuccessHandler()) // redirección personalizada
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/?logout") // redirige al index cuando cierre sesión
                .permitAll()
            )
            .sessionManagement(session -> session
                .maximumSessions(1) // permite solo 1 sesión activa
                .maxSessionsPreventsLogin(false) // si abres en otro navegador, cierra la sesión anterior
            )
            .headers(headers -> headers.frameOptions().disable()); // necesario para h2-console

        return http.build();
    }

    @Bean
    public AuthenticationSuccessHandler customAuthenticationSuccessHandler() {
        return (request, response, authentication) -> {
            var roles = authentication.getAuthorities().toString();
            if (roles.contains("ROLE_ADMIN")) {
                response.sendRedirect("/admin/home?success");
            } else if (roles.contains("ROLE_DEPORTISTA")) {
                response.sendRedirect("/deportista/home?success");
            } else if (roles.contains("ROLE_MEDICO")) {
                response.sendRedirect("/medico/home?success");
            } else if (roles.contains("ROLE_ENTRENADOR")) {
                response.sendRedirect("/entrenador/home?success");
            } else {
                response.sendRedirect("/home?success");
            }
        };
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
