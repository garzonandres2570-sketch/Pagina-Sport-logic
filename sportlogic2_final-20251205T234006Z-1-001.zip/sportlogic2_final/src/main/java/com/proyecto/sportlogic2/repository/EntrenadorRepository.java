package com.proyecto.sportlogic2.repository;

import com.proyecto.sportlogic2.model.Entrenador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EntrenadorRepository extends JpaRepository<Entrenador, Long> {
}
