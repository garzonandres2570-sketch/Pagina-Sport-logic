package com.proyecto.sportlogic2.controller;

import com.proyecto.sportlogic2.model.Jugador;
import com.proyecto.sportlogic2.repository.JugadorRepository;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/deportista")
public class DeportistaController {

    private final JugadorRepository jugadorRepo;

    public DeportistaController(JugadorRepository jugadorRepo) {
        this.jugadorRepo = jugadorRepo;
    }

    
    @GetMapping("/home")
    public String home() {
        return "deportista/home"; 
    }

    
    @GetMapping("/perfil")
    public String verPerfil(Authentication auth, Model model) {
        String email = auth.getName(); 

        
        Jugador jugador = jugadorRepo.findByEmail(email).orElse(null);

        
        if (jugador == null) {
            jugador = new Jugador();
            jugador.setEmail(email);
            jugadorRepo.save(jugador);
        }

        model.addAttribute("jugador", jugador);
        return "deportista/perfil";
    }

    
    @PostMapping("/perfil")
    public String actualizarPerfil(@ModelAttribute Jugador formJugador, Authentication auth) {
        String email = auth.getName();
        Jugador jugador = jugadorRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Jugador no encontrado"));

        
        jugador.setNombre(formJugador.getNombre());
        jugador.setEdad(formJugador.getEdad());
        jugador.setPosicion(formJugador.getPosicion());
        jugador.setNacionalidad(formJugador.getNacionalidad());
        jugador.setEstadoFisico(formJugador.getEstadoFisico());

        
        jugador.setEmail(email);

        jugadorRepo.save(jugador);
        return "redirect:/deportista/perfil?success";
    }

    
    @GetMapping("/entrenamientos")
    public String entrenamientos() {
        return "deportista/entrenamientos";
    }

    
    @GetMapping("/estado")
public String estado(Authentication auth, Model model) {
    String email = auth.getName();
    Jugador jugador = jugadorRepo.findByEmail(email).orElse(null);

    model.addAttribute("jugador", jugador);
    return "deportista/estado";
}

    
}
