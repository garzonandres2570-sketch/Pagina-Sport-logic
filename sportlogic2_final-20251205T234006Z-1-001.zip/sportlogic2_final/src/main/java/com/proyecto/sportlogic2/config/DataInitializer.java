package com.proyecto.sportlogic2.config;

import com.proyecto.sportlogic2.model.Entrenamiento;
import com.proyecto.sportlogic2.model.Jugador;
import com.proyecto.sportlogic2.model.Usuario;
import com.proyecto.sportlogic2.repository.EntrenamientoRepository;
import com.proyecto.sportlogic2.repository.JugadorRepository;
import com.proyecto.sportlogic2.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner init(UsuarioRepository ur, JugadorRepository jr,
                           EntrenamientoRepository er, PasswordEncoder pe) {
        return args -> {
            if (ur.findByEmail("admin@club.com").isEmpty()) {
                Usuario a = new Usuario();
                a.setNombre("Admin");
                a.setEmail("admin@club.com");
                a.setPassword(pe.encode("admin"));
                a.setRol("ADMIN");
                ur.save(a);

                Usuario p = new Usuario();
                p.setNombre("Jugador Uno");
                p.setEmail("player@club.com");
                p.setPassword(pe.encode("player"));
                p.setRol("DEPORTISTA");
                ur.save(p);

                Usuario m = new Usuario();
                m.setNombre("Medico");
                m.setEmail("medico@club.com");
                m.setPassword(pe.encode("medico"));
                m.setRol("MEDICO");
                ur.save(m);

                Usuario t = new Usuario();
                t.setNombre("Entrenador");
                t.setEmail("entrenador@club.com");
                t.setPassword(pe.encode("entrenador"));
                t.setRol("ENTRENADOR");
                ur.save(t);
            }

            if (jr.count() == 0) {
                Jugador j = new Jugador();
                j.setNombre("Juan Perez");
                j.setEdad(24);
                j.setPosicion("Delantero");
                j.setEstadoFisico("Bueno");
                j.setNacionalidad("Colombiano");
                j.setEmail("juan.perez@club.com");
                jr.save(j);

                Jugador j2 = new Jugador();
                j2.setNombre("Carlos Ruiz");
                j2.setEdad(28);
                j2.setPosicion("Defensa");
                j2.setEstadoFisico("Recuperación");
                j2.setNacionalidad("Argentino");
                j2.setEmail("player@club.com");
                jr.save(j2);
            }

            if (er.count() == 0) {
                Entrenamiento e = new Entrenamiento();
                e.setTitulo("Táctica ofensiva");
                e.setDescripcion("Trabajo de finalización");
                e.setFechaHora(LocalDateTime.now().plusDays(1).withHour(15).withMinute(0));
                e.setLugar("Cancha 1");
                er.save(e);
            }
        };
    }
}
