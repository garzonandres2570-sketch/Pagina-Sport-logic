package com.proyecto.sportlogic2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin/reportes")
public class AdminReporteController {

    @GetMapping
    public String reportes(Model model) {
        model.addAttribute("mensaje", "Aquí irán los reportes generados con filtros multicriterio");
        return "admin/reportes";
    }
}
