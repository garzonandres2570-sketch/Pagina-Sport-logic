package com.proyecto.sportlogic2.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Getter
@Setter
public class HistorialClinico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate fecha = LocalDate.now();

    private String descripcion; 
    private String diagnostico;
    private String tratamiento;

    @ManyToOne
    @JoinColumn(name = "jugador_id")
    private Jugador jugador;
}
