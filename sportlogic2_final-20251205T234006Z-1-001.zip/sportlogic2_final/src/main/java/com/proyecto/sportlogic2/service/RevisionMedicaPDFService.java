package com.proyecto.sportlogic2.service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.proyecto.sportlogic2.model.RevisionMedica;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;

@Service
public class RevisionMedicaPDFService {

    public ByteArrayInputStream exportarPdf(List<RevisionMedica> revisiones) {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            
            Font fontTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK);
            Paragraph titulo = new Paragraph("Reporte de Revisiones Médicas", fontTitulo);
            titulo.setAlignment(Element.ALIGN_CENTER);
            document.add(titulo);
            document.add(new Paragraph(" ")); 

            
            PdfPTable table = new PdfPTable(5);
            table.setWidthPercentage(100);

            
            String[] headers = {"Jugador", "Fecha", "Estado de Salud", "Observaciones", "Estado Actual (Jugador)"};
            for (String h : headers) {
                PdfPCell header = new PdfPCell(new Phrase(h));
                header.setBackgroundColor(BaseColor.LIGHT_GRAY);
                header.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(header);
            }

            
            for (RevisionMedica r : revisiones) {
                
                String jugadorNombre = (r.getJugador() != null) ? r.getJugador().getNombre() : "N/A";
                table.addCell(jugadorNombre);

            
                table.addCell(String.valueOf(r.getFecha()));

               
                table.addCell(String.valueOf(r.getEstadoSalud()));

                
                table.addCell((r.getObservaciones() != null) ? r.getObservaciones() : "-");

                
                String estadoJugador = (r.getJugador() != null) ? r.getJugador().getEstadoSalud() : "N/A";
                table.addCell(estadoJugador);
            }

            document.add(table);
            document.close();

        } catch (DocumentException e) {
            e.printStackTrace();
        }

        return new ByteArrayInputStream(out.toByteArray());
    }
}
