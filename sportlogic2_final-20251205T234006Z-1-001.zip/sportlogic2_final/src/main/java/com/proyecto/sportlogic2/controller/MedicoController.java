package com.proyecto.sportlogic2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MedicoController {

    @GetMapping("/medico/home")
    public String home() {
        return "medico/home"; 
    }
}
