package com.proyecto.sportlogic2.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
public class Jugador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String posicion;
    private Integer edad;
    private String nacionalidad;

    private String estadoFisico; 
    private String estadoSalud;  

    @Column(unique = true, nullable = false)
    private String email;

   
    @OneToMany(mappedBy = "jugador", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<RevisionMedica> revisiones = new ArrayList<>();
}
