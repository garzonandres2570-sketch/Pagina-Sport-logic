package com.proyecto.sportlogic2.controller;

import com.proyecto.sportlogic2.model.EstadoFisico;
import com.proyecto.sportlogic2.model.Jugador;
import com.proyecto.sportlogic2.repository.EstadoFisicoRepository;
import com.proyecto.sportlogic2.repository.JugadorRepository;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/estado")
public class EstadoFisicoController {

    private final EstadoFisicoRepository estadoRepo;
    private final JugadorRepository jugadorRepo;

    public EstadoFisicoController(EstadoFisicoRepository estadoRepo, JugadorRepository jugadorRepo) {
        this.estadoRepo = estadoRepo;
        this.jugadorRepo = jugadorRepo;
    }

    
    @GetMapping("/jugador")
    public String verEstadoJugador(Authentication auth, Model model) {
        String email = auth.getName();
        Jugador jugador = jugadorRepo.findByEmail(email).orElseThrow();
        EstadoFisico estado = estadoRepo.findByJugador(jugador).orElse(null);

        model.addAttribute("estado", estado);
        return "jugador/estado";
    }

    
    @GetMapping("/medico/{jugadorId}")
    public String editarEstado(@PathVariable Long jugadorId, Model model) {
        Jugador jugador = jugadorRepo.findById(jugadorId).orElseThrow();
        EstadoFisico estado = estadoRepo.findByJugador(jugador).orElse(new EstadoFisico());
        estado.setJugador(jugador);

        model.addAttribute("estado", estado);
        return "medico/estado-form";
    }

    @PostMapping("/medico/guardar")
    public String guardarEstado(@ModelAttribute EstadoFisico estado) {
        estadoRepo.save(estado);
        return "redirect:/admin/jugadores";
    }
}
