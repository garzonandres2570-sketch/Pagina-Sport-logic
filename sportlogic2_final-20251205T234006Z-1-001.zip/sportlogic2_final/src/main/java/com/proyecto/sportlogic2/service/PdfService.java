package com.proyecto.sportlogic2.service;

import com.proyecto.sportlogic2.model.Entrenamiento;
import com.proyecto.sportlogic2.model.RevisionMedica;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class PdfService {

    
    public void generarEntrenamientosPdf(List<Entrenamiento> lista, HttpServletResponse response) throws DocumentException, IOException {
        Document doc = new Document(PageSize.A4);
        PdfWriter.getInstance(doc, response.getOutputStream());
        doc.open();

       
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
        Paragraph title = new Paragraph("Reporte de Entrenamientos", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        doc.add(title);
        doc.add(new Paragraph("\n"));

     
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setWidths(new float[]{1f, 3f, 4f, 2f, 2f});

        
        addHeaderCell(table, "ID");
        addHeaderCell(table, "Título");
        addHeaderCell(table, "Descripción");
        addHeaderCell(table, "Fecha y Hora");
        addHeaderCell(table, "Lugar");

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        for (Entrenamiento e : lista) {
            addCell(table, e.getId() == null ? "" : String.valueOf(e.getId()));
            addCell(table, safe(e.getTitulo()));
            addCell(table, safe(e.getDescripcion()));
            addCell(table, e.getFechaHora() == null ? "" : e.getFechaHora().format(dtf));
            addCell(table, safe(e.getLugar()));
        }

        doc.add(table);
        doc.close();
        response.getOutputStream().flush();
    }

    
    public void generarRevisionesPdf(List<RevisionMedica> lista, HttpServletResponse response) throws DocumentException, IOException {
        Document doc = new Document(PageSize.A4.rotate()); // rotamos para más columnas si hace falta
        PdfWriter.getInstance(doc, response.getOutputStream());
        doc.open();

        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
        Paragraph title = new Paragraph("Reporte de Revisiones Médicas", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        doc.add(title);
        doc.add(new Paragraph("\n"));

        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setWidths(new float[]{1f, 3f, 2f, 2f, 5f}); // ID, Jugador, Fecha, Estado, Observaciones

        addHeaderCell(table, "ID");
        addHeaderCell(table, "Jugador");
        addHeaderCell(table, "Fecha");
        addHeaderCell(table, "Estado Salud");
        addHeaderCell(table, "Observaciones");

        DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        for (RevisionMedica r : lista) {
            addCell(table, r.getId() == null ? "" : String.valueOf(r.getId()));
            addCell(table, r.getJugador() != null ? safe(r.getJugador().getNombre()) : "");
            addCell(table, r.getFecha() != null ? r.getFecha().format(df) : "");
            addCell(table, safe(r.getEstadoSalud()));
            addCell(table, safe(r.getObservaciones()));
        }

        doc.add(table);
        doc.close();
        response.getOutputStream().flush();
    }

  
    private void addHeaderCell(PdfPTable t, String text) {
        Font hFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
        PdfPCell cell = new PdfPCell(new Phrase(text, hFont));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
        t.addCell(cell);
    }

    private void addCell(PdfPTable t, String text) {
        PdfPCell cell = new PdfPCell(new Phrase(text == null ? "" : text));
        cell.setPadding(4);
        t.addCell(cell);
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }
}
