package com.proyecto.sportlogic2.service;

import com.proyecto.sportlogic2.model.Entrenador;
import com.proyecto.sportlogic2.repository.EntrenadorRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EntrenadorService {

    private final EntrenadorRepository entrenadorRepository;

    public EntrenadorService(EntrenadorRepository entrenadorRepository) {
        this.entrenadorRepository = entrenadorRepository;
    }

    public List<Entrenador> listarTodos() {
        return entrenadorRepository.findAll();
    }

    public Optional<Entrenador> obtenerPorId(Long id) {
        return entrenadorRepository.findById(id);
    }

    public Entrenador guardar(Entrenador entrenador) {
        return entrenadorRepository.save(entrenador);
    }

    public void eliminar(Long id) {
        entrenadorRepository.deleteById(id);
    }
}
