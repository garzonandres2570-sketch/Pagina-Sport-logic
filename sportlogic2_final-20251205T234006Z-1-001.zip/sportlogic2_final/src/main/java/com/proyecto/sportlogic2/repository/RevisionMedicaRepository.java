package com.proyecto.sportlogic2.repository;

import com.proyecto.sportlogic2.model.RevisionMedica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RevisionMedicaRepository extends JpaRepository<RevisionMedica, Long> {

    @Query("SELECT r FROM RevisionMedica r " +
           "WHERE (:diagnostico IS NULL OR r.diagnostico LIKE %:diagnostico%) " +
           "AND (:estadoSalud IS NULL OR r.estadoSalud = :estadoSalud)")
    List<RevisionMedica> findByFiltros(@Param("diagnostico") String diagnostico,
                                       @Param("estadoSalud") String estadoSalud);
}
