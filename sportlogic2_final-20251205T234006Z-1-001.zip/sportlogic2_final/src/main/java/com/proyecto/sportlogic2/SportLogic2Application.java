
package com.proyecto.sportlogic2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SportLogic2Application {
    public static void main(String[] args) {
        SpringApplication.run(SportLogic2Application.class, args);
    }
}
