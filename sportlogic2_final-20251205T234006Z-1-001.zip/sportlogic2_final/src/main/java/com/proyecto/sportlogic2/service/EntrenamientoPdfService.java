package com.proyecto.sportlogic2.service;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.proyecto.sportlogic2.model.Entrenamiento;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class EntrenamientoPdfService {

    public void export(HttpServletResponse response, List<Entrenamiento> entrenamientos) throws IOException, DocumentException {
        Document doc = new Document();
        PdfWriter.getInstance(doc, response.getOutputStream());
        doc.open();

        doc.add(new Paragraph("📋 Reporte de Entrenamientos\n\n"));

        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);

        // Encabezados
        table.addCell("ID");
        table.addCell("Título");
        table.addCell("Descripción");
        table.addCell("Fecha y Hora");
        table.addCell("Lugar");

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        for (Entrenamiento e : entrenamientos) {
            table.addCell(String.valueOf(e.getId()));
            table.addCell(e.getTitulo() != null ? e.getTitulo() : "");
            table.addCell(e.getDescripcion() != null ? e.getDescripcion() : "");
            table.addCell(e.getFechaHora() != null ? e.getFechaHora().format(fmt) : "");
            table.addCell(e.getLugar() != null ? e.getLugar() : "");
        }

        doc.add(table);
        doc.close();
    }
}
