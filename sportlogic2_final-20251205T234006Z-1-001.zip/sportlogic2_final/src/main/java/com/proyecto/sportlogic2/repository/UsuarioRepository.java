package com.proyecto.sportlogic2.repository;

import com.proyecto.sportlogic2.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    Optional<Usuario> findByEmail(String email);

    @Query("SELECT u FROM Usuario u " +
           "WHERE (:nombre IS NULL OR :nombre = '' OR LOWER(u.nombre) LIKE LOWER(CONCAT('%',:nombre,'%'))) " +
           "AND (:email IS NULL OR :email = '' OR LOWER(u.email) LIKE LOWER(CONCAT('%',:email,'%'))) " +
           "AND (:rol IS NULL OR :rol = '' OR UPPER(u.rol) = UPPER(:rol))")
    List<Usuario> findByFiltros(@Param("nombre") String nombre,
                                @Param("email") String email,
                                @Param("rol") String rol);
}
