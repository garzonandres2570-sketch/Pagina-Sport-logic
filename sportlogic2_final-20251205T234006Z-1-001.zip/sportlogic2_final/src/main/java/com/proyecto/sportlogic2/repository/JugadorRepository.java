package com.proyecto.sportlogic2.repository;

import com.proyecto.sportlogic2.model.Jugador;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface JugadorRepository extends JpaRepository<Jugador, Long> {

   
    Optional<Jugador> findByEmail(String email);

    
    @Query("SELECT j FROM Jugador j " +
           "WHERE (:nombre IS NULL OR LOWER(j.nombre) LIKE LOWER(CONCAT('%', :nombre, '%'))) " +
           "AND (:posicion IS NULL OR LOWER(j.posicion) LIKE LOWER(CONCAT('%', :posicion, '%'))) " +
           "AND (:edadMin IS NULL OR j.edad >= :edadMin) " +
           "AND (:edadMax IS NULL OR j.edad <= :edadMax) " +
           "AND (:nacionalidad IS NULL OR LOWER(j.nacionalidad) LIKE LOWER(CONCAT('%', :nacionalidad, '%')))")
    List<Jugador> findByFiltros(@Param("nombre") String nombre,
                                @Param("posicion") String posicion,
                                @Param("edadMin") Integer edadMin,
                                @Param("edadMax") Integer edadMax,
                                @Param("nacionalidad") String nacionalidad);
}
