package com.proyecto.sportlogic2.repository;

import com.proyecto.sportlogic2.model.EstadoFisico;
import com.proyecto.sportlogic2.model.Jugador;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EstadoFisicoRepository extends JpaRepository<EstadoFisico, Long> {
    Optional<EstadoFisico> findByJugador(Jugador jugador);
}
